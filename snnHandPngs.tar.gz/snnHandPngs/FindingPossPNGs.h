/*
 * FindingPossPNGs.h
 *
 *  Created on: Sep 20, 2015
 *      Author: banafsheh
 */

#ifndef FINDINGPOSSPNGS_H_
#define FINDINGPOSSPNGS_H_

int* FindigPossPNGs(int size);


#endif /* FINDINGPOSSPNGS_H_ */
